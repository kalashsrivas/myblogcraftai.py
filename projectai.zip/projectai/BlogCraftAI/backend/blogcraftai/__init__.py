"""BlogCraftAI Django project."""

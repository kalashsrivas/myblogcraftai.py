# Content Operations Blueprint Template

## Workflow Overview
- Trigger event:
- Content stages:
- Tooling per stage:

## Roles & Responsibilities
| Role | Responsibilities | Backup |
| ---- | ---------------- | ------ |
|      |                  |        |

## SLA & Deadlines
- Draft completion:
- Review turnaround:
- Publication window:

## Quality Gates
- Editorial review checklist:
- SEO review checklist:
- Accessibility audit:

## Risk Register
| Risk | Impact | Likelihood | Mitigation |
| ---- | ------ | ---------- | ---------- |
|      |        |            |            |

## Communication Plan
- Standups & cadence:
- Reporting channels:
- Escalation contacts:

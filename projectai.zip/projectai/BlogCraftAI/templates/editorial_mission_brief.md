# Editorial Mission Brief Template

## Mission Statement
- Our editorial mission is to...

## Audience Overview
- Priority personas:
- Core needs:

## Voice & Tone
- Adjectives that describe our voice:
- Style guidelines:

## Content Pillars
1. Pillar 1 — Focus area & desired action
2. Pillar 2 — Focus area & desired action
3. Pillar 3 — Focus area & desired action

## Distribution Strategy
- Primary channels:
- Syndication partners:
- Cadence & timing:

## Success Metrics
- North star metric:
- Supporting KPIs:

## Governance
- Approval workflow:
- Review cadence:
- Escalation path:

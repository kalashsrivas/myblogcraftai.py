# Template Library

Use these templates during the starter track workshops. Duplicate the files for each team and store completed versions in the cohort workspace.

- `value_proposition_canvas.md`
- `editorial_mission_brief.md`
- `content_ops_blueprint.md`
- `kpi_dashboard_outline.md`
- `capstone_brief.md`
- `learning_plan.md`

Feel free to extend the library with additional templates as new needs arise. Maintain consistent formatting for ease of use.

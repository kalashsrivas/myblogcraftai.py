# RACI Template – Automation Workflow

| Role | Person/Team | Responsible (R) | Accountable (A) | Consulted (C) | Informed (I) |
| --- | --- | --- | --- | --- | --- |
| Product Owner |  |  |  |  |  |
| Automation Engineer |  |  |  |  |  |
| Backend Engineer |  |  |  |  |  |
| Security |  |  |  |  |  |
| Legal/Compliance |  |  |  |  |  |
| Operations (On-call) |  |  |  |  |  |
| Content Team |  |  |  |  |  |

